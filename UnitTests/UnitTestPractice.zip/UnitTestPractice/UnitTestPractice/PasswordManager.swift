//
//  PasswordManager.swift
//  UnitTestPractice
//
//  Created by Julian Arias Maetschl on 23-04-21.
//

import Foundation

struct PasswordManager {

    func validate(password: String) -> Bool {
        hasUppercaseValue(password) && hasNumber(password)
    }

    private func hasUppercaseValue(_ password: String) -> Bool {
        for character in password {
            if character.isUppercase {
                return true
            }
        }
        return false
    }

    private func hasNumber(_ password: String) -> Bool {
        for character in password {
            if character.isNumber {
                return true
            }
        }
        return false
    }

}


