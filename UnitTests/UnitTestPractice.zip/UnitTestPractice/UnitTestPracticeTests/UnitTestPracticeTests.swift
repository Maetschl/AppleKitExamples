//
//  UnitTestPracticeTests.swift
//  UnitTestPracticeTests
//
//  Created by Julian Arias Maetschl on 23-04-21.
//

import XCTest
@testable import UnitTestPractice

class UnitTestPracticeTests: XCTestCase {

    var sut: PasswordManager!

    override func setUpWithError() throws {
        sut = PasswordManager()
    }

    override func tearDownWithError() throws {
        sut = nil
    }

    func testValidInputPassword() throws {
        // Given
        let password: String = "Value1"
        // When
        let result = sut.validate(password: password)
        // Then
        XCTAssertTrue(result)
    }

    func testFailIfnotOneUpperCaseCharacter() throws {
        // Given
        let password: String = "value"
        // When
        let result = sut.validate(password: password)
        // Then
        XCTAssertFalse(result)
    }

    func testOneUpperCaseCharacter() {
        // Given
        let password: String = "vaLue1"
        // When
        let result = sut.validate(password: password)
        // Then
        XCTAssertTrue(result)
    }

    func testNumberOnPassword() {
        // Given
        let password: String = "1vaLue"
        // When
        let result = sut.validate(password: password)
        // Then
        XCTAssertTrue(result)
    }

    func testNumberOnPasswordFail() {
        // Given
        let password: String = "vaLue"
        // When
        let result = sut.validate(password: password)
        // Then
        XCTAssertFalse(result)
    }

}

class NetworkServiceSpy {
    var callIsCalled = false
    func call() -> String {
        callIsCalled = true
        return ""
    }
}
